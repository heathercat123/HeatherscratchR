Scratch MSI Installer README file

The .msi installer file will install Scratch and copy the Scratch.ini file in the same folder as the installer.

To customize proxy settings, hidden drives, and other settings, edit values in Scratch.ini before installation
See: 

http://info.scratch.mit.edu/Network_Installation 

...for more infomation. 

To install silently, use the following command, where <MSI path> is the path to Scratch1.4.msi
msiexec /i <MSI path> /qn

Scratch On!